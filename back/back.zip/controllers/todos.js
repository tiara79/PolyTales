// file: back/controllers/notes.js

const models = require("../models");

const getNotesByMonth = async (req, res) => {
  const { month } = req.params;
  const paddedMonth = month.toString().padStart(2, '0'); // '6' → '06'

  try {
    const notes = await models.note.findAll({
      where: models.sequelize.where(
        models.sequelize.fn('strftime', '%m', models.sequelize.col('date')),
        paddedMonth
      )
    });
    res.status(200).json(notes);
  } catch (error) {
    console.error("월별 데이터 조회 실패:", error);
    res.status(500).json({ message: "월별 메모 조회 중 오류 발생" });
  }
};


const createnote = async (req, res) => {
  const { task, description } = req.body;
  const note = await models.note.create({
    task: task,
    description: description,
  });
  res.status(201).json({ message: "ok", data: note });
};

const findAllnotes = async (req, res) => {
  const notes = await models.note.findAll();
  res.status(200).json({ message: "ok", data: notes });
};

const findnote = async (req, res) => {
  const id = req.params.id;
  const note = await models.note.findByPk(id);
  if (note) {
    res.status(200).json({ message: "ok", data: note });
  } else {
    res.status(404).json({ message: `할일을 찾을 수 없어요` });
  }
};

const updatenote = async (req, res) => {
  const id = req.params.id;
  const { task, description, completed, priority } = req.body;
  const note = await models.note.findByPk(id);
  if (note) {
    if (task) note.task = task;
    if (description) note.description = description;
    if (completed) note.completed = completed;
    if (priority) note.priority = priority;
    await note.save();
    res.status(200).json({ message: "ok", data: note });
  } else {
    res.status(404).json({ message: "할일이 없어" });
  }
};

const deletenote = async (req, res) => {
  const id = req.params.id;
  const result = await models.note.destroy({
    where: { id: id },
  });
  console.log(result); // result 숫자이고 지운 행의 갯수
  if (result > 0) {
    res.status(200).json({ message: "삭제가 성공했어용" });
  } else {
    res.status(404).json({ message: "할일 없어용" });
  }
};

module.exports = {
  createnote,
  findAllnotes,
  findnote,
  updatenote,
  deletenote,
};