module.exports = (sequelize, DataTypes) => {
  const Note = sequelize.define('Note', {
    noteId: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    userId: DataTypes.INTEGER,
    storyId: DataTypes.INTEGER,
    title: DataTypes.TEXT,
    content: DataTypes.TEXT,
    createdAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW
    }
  }, {
    tableName: 'Note',
    timestamps: false
  });

  Note.associate = (models) => {
    Note.belongsTo(models.User, { foreignKey: 'userId' });
    Note.belongsTo(models.Story, { foreignKey: 'storyId' });
  };

  return Note;
};
